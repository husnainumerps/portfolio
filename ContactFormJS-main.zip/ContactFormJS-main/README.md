# ContactFormJS
Sending Contact form data as email through javascript using SMTPJS

Please replace dotted lines with your own account credentials.
