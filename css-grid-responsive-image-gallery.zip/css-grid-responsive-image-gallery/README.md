# CSS Grid Responsive Image Gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/ramenhog/pen/MpORPa](https://codepen.io/ramenhog/pen/MpORPa).

Playing around with CSS Grid in responsive image galleries.

Can you tell what I was craving when I made this?.....